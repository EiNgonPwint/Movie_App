package iss.workshop.adproject_team5_movieapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.TextView;


import java.util.List;

import iss.workshop.adproject_team5_movieapp.Adapter.MovieRecyclerView;
import iss.workshop.adproject_team5_movieapp.Adapter.OnMovieClickListener;
import iss.workshop.adproject_team5_movieapp.Model.Movie;
import iss.workshop.adproject_team5_movieapp.Model.User;
import iss.workshop.adproject_team5_movieapp.ViewModel.MovieViewModel;

public class FilmsFragment extends Fragment implements OnMovieClickListener {

    private RecyclerView recyclerView;

    MovieRecyclerView movieRecyclerView;
    private MovieViewModel movieViewModel;
    private TextView popularMovietxtview;
    private SearchView searchView;

    boolean displayPopular = true;
    User user;
    public FilmsFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //createSearchView();


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_films, container, false);
        // createSearchView();

        // Inflate the layout for this fragment

        //add user
        Bundle bundle = getArguments();
        user = (User) bundle.getSerializable("user");


        return  view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //createSearchView();

        //searchView=view.findViewById(R.id.search_view);
        recyclerView = view.findViewById(R.id.recyclerView);
        popularMovietxtview = view.findViewById(R.id.popularLabel);
        searchView = view.findViewById(R.id.search_view);



        movieViewModel = new ViewModelProvider(this).get(MovieViewModel.class);

        createRecyclerView();
        ObserveChange();
        ObservePopular();
        createSearchView();
        movieViewModel.searchMoviePopular(1);
    }

    @Override
    public void onMovieClick(View v, int position) {
        Intent intent = new Intent(getActivity(), MovieDetailsActivity.class);
        Movie mm=movieRecyclerView.getSelectedMovie(position);
        intent.putExtra("movie", movieRecyclerView.getSelectedMovie(position));
        //mm some attributes null
        intent.putExtra("user",user);
        startActivity(intent);
    }
    private void createSearchView(){



        searchView.setOnSearchClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //when search view is clicked
                displayPopular = false;
                popularMovietxtview.setVisibility(View.GONE);
            }
        });
        searchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                //when search view is closed
                popularMovietxtview.setVisibility(View.VISIBLE);
                movieViewModel.searchMoviePopular(1);
                displayPopular = true;
                return false;
            }
        });

        // Make search query
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String query) {

                // query is obtained from search view on submit
                movieViewModel.searchMovieApi(
                        query,
                        1
                );
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                movieViewModel.searchMovieApi(
                        newText,
                        1
                );
                return false;
            }
        });
    }

    private void ObserveChange(){

        movieViewModel.getMovies().observe(getViewLifecycleOwner(), new Observer<List<Movie>>(){
            @Override
            public void onChanged(List<Movie> movies) {
                if (movies != null){
                    for (Movie movie:movies){
                        Log.v("Tagy", "onChanged " + movie.getTitle());
                        movieRecyclerView.setMovieList(movies);
                    }
                }

            }
        });
    }

    private void ObservePopular(){
        movieViewModel.getPopular().observe(getViewLifecycleOwner(), new Observer<List<Movie>>() {
            @Override
            public void onChanged(List<Movie> movies) {
                if (movies != null){
                    movieRecyclerView.setMovieList(movies);
                }
            }
        });


    }

    private void createRecyclerView(){

        //pass listener via constructor, cant pass Live Data this way
        movieRecyclerView = new MovieRecyclerView(this);

        recyclerView.setAdapter(movieRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.getContext(), LinearLayoutManager.HORIZONTAL, false));

        // RecyclerView Pagination
        // Loading next page of api response
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                if (!recyclerView.canScrollVertically(1)){
                    // Here we need to display the next search results on the next page of api
                    movieViewModel.searchNextpage();

                }

            }
        });
    }

}