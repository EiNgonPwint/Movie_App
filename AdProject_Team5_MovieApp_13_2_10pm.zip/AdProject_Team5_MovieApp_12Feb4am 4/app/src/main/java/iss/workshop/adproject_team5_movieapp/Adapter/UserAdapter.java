package iss.workshop.adproject_team5_movieapp.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import iss.workshop.adproject_team5_movieapp.Model.Movie;
import iss.workshop.adproject_team5_movieapp.Model.User;
import iss.workshop.adproject_team5_movieapp.R;

public class UserAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>  {
    private List<User> userList;
    private OnFollowClickListener onFollowClickListener;

    public  UserAdapter(OnFollowClickListener onFollowClickListener){
        this.onFollowClickListener=onFollowClickListener;
    }
    public UserAdapter(List<User> userList, OnFollowClickListener onFollowClickListener)
    {
        this.userList = userList;
        this.onFollowClickListener=onFollowClickListener;
    }
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_user_list, parent, false);
        return new UserHolder(view,onFollowClickListener);

    }


    public void filterList(List<User> filterList)
    {
        userList = filterList;
        notifyDataSetChanged();
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        User user = userList.get(position);

        ((UserHolder)holder).name.setText(user.getName());
        ((UserHolder)holder).email.setText(user.getEmail());
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    public User getSelectedUser(int position){
        if (userList != null){
            if (userList.size() > 0){
                return userList.get(position);
            }
        }
        return null;
    }

}
