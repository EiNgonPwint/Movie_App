package iss.workshop.adproject_team5_movieapp.Adapter;

import android.view.View;

public interface OnFollowClickListener {

    void onFollowClick(View v, int position);
}
