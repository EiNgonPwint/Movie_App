package iss.workshop.adproject_team5_movieapp.utils;

public class TmdbApiCred {

    public static final String BASE_URL = "https://api.themoviedb.org/";
    public static final String API_KEY = "ac9520092f0240763841215ba5232cef";
    public static boolean displayPopularMovies = false;

}
