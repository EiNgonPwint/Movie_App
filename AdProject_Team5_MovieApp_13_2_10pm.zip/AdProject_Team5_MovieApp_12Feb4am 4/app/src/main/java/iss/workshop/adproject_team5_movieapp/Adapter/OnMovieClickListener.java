package iss.workshop.adproject_team5_movieapp.Adapter;

import android.view.View;

public interface OnMovieClickListener {

    void onMovieClick(View v, int position);

}
