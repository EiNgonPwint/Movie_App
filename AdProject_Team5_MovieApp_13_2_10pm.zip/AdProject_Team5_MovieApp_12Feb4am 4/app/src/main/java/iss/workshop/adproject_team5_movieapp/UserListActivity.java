//package iss.workshop.adproject_team5_movieapp;
//
//import android.os.Bundle;
//import android.view.Menu;
//import android.view.MenuItem;
//import android.widget.SearchView;
//import android.widget.Toast;
//
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;
//
//import java.util.List;
//
//import iss.workshop.adproject_team5_movieapp.Adapter.UserAdapter;
//import iss.workshop.adproject_team5_movieapp.Model.User;
//import iss.workshop.adproject_team5_movieapp.retrofit.RetrofitService;
//import iss.workshop.adproject_team5_movieapp.utils.MovieApi;
//import retrofit2.Call;
//import retrofit2.Callback;
//import retrofit2.Response;
//
//public class UserListActivity extends AppCompatActivity {
//    private RecyclerView recyclerView;
//    private String name;
//    UserAdapter userAdapter;
//    private List<User> userModelArrayList;
//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        getMenuInflater().inflate(R.menu.menu,menu);
//        MenuItem menuItem = menu.findItem(R.id.action_search);
//        SearchView searchView = (SearchView) menuItem.getActionView();
//        searchView.setQueryHint("Type Here to search");
//        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
//            @Override
//            public boolean onQueryTextSubmit(String query) {
//
//                name =searchView.getQuery().toString();
//                loadEmployee(name);
//                System.out.println("search query submit");
//                System.out.println(name);
//                return true;
//            }
//
//            @Override
//            public boolean onQueryTextChange(String newText) {
//
//                return false;
//            }
//        });
//        return super.onCreateOptionsMenu(menu);
//    }
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_user_list);
//        recyclerView = findViewById(R.id.userList);
//        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//        loadEmployee(name);
//        System.out.println(name);
//
//    }
//    private void loadEmployee(String name)
//    {
//        RetrofitService retrofitService = new RetrofitService();
//        MovieApi movieApi= retrofitService.getRetrofit().create(MovieApi.class);
//
//        movieApi.getAllUserByName(name)
//                .enqueue(new Callback<List<User>>() {
//                    @Override
//                    public void onResponse(Call<List<User>> call, Response<List<User>> response) {
//                        //list users from Users
//                        populateListView(response.body());
//                    }
//
//                    @Override
//                    public void onFailure(Call<List<User>> call, Throwable t) {
//                        Toast.makeText(UserListActivity.this, "Failed to load employees", Toast.LENGTH_SHORT).show();
//                    }
//                });
//    }
//    private void populateListView(List<User> userList) {
//        userAdapter = new UserAdapter(userList);
//        recyclerView.setAdapter(userAdapter);
//    }
//    @Override
//    protected void onResume() {
//
//        super.onResume();
//        loadEmployee(name);
//    }
//}